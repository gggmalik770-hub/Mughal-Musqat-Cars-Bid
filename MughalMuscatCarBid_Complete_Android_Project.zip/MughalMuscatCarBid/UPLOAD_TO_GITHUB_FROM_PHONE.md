# Upload from phone

1. Extract this ZIP on your phone.
2. Open the GitHub repository `Mughal-Musqat-Cars-Bid`.
3. Do not upload the ZIP itself. Open the extracted `MughalMuscatCarBid` folder.
4. In GitHub choose Add file -> Upload files.
5. Upload the project files/folders so that `settings.gradle`, `build.gradle`, `gradle.properties`, `app/`, and `.github/` are at the repository root.
6. Commit directly to `main`.
7. Open Actions. The `Build APK` workflow will start automatically.
8. Open the completed run and download the artifact named `Mughal-Muscat-Car-Bid-APK`.
